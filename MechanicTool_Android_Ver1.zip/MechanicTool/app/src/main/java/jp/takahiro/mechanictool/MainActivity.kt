package jp.takahiro.mechanictool

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlin.math.ceil
import kotlin.math.pow
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MechanicToolApp() }
    }
}

enum class Screen { HOME, PRESSURE, DIAMETER, AC }
enum class TireStandard(val label: String, val referenceKpa: Int) {
    STD("乗用 STD", 250),
    XL("乗用 XL / RF", 290),
    LT_C("LT Load Range C", 350),
    LT_D("LT Load Range D", 450),
    LT_E("LT Load Range E", 550)
}

data class TireInput(
    val width: Int = 195,
    val aspect: Int = 65,
    val rim: Int = 15,
    val loadIndex: Int = 91,
    val standard: TireStandard = TireStandard.STD,
    val pressureKpa: Int = 230
)

data class PressureResult(
    val frontKpa: Int,
    val rearKpa: Int,
    val frontLoadKg: Double,
    val rearLoadKg: Double,
    val frontStatus: String,
    val rearStatus: String
)

@Composable
fun MechanicToolApp() {
    var screen by remember { mutableStateOf(Screen.HOME) }
    val goHome = { screen = Screen.HOME }
    if (screen != Screen.HOME) BackHandler { goHome() }

    MaterialTheme(
        colorScheme = lightColorScheme(),
        typography = Typography()
    ) {
        Surface(Modifier.fillMaxSize()) {
            when (screen) {
                Screen.HOME -> HomeScreen(onSelect = { screen = it })
                Screen.PRESSURE -> TirePressureScreen(onBack = goHome)
                Screen.DIAMETER -> TireDiameterScreen(onBack = goHome)
                Screen.AC -> AcDiagnosticScreen(onBack = goHome)
            }
        }
    }
}

@Composable
private fun HomeScreen(onSelect: (Screen) -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Spacer(Modifier.height(10.dp))
        Text("🔧 整備士ツール", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("現場で素早く使える、オフライン計算・診断ツール")
        Spacer(Modifier.height(8.dp))
        MenuCard("① タイヤ空気圧計算", "前後別・STD / XL / LT対応", "🛞") { onSelect(Screen.PRESSURE) }
        MenuCard("② タイヤ外径計算", "インチアップ／ダウン・速度誤差", "📏") { onSelect(Screen.DIAMETER) }
        MenuCard("③ エアコンガス点検", "高低圧から診断候補を表示", "❄️") { onSelect(Screen.AC) }
        Spacer(Modifier.weight(1f))
        Text("Ver. 1.0  •  端末内だけで動作", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun MenuCard(title: String, subtitle: String, emoji: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        elevation = CardDefaults.cardElevation(3.dp)
    ) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(emoji, style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.width(14.dp))
            Column {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(subtitle, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun AppHeader(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = onBack) { Text("← 戻る") }
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun TirePressureScreen(onBack: () -> Unit) {
    var sameSizeFrontRear by remember { mutableStateOf(true) }

    var oldFront by remember { mutableStateOf(TireInput(195, 65, 15, 91, TireStandard.STD, 230)) }
    var oldRear by remember { mutableStateOf(oldFront.copy()) }
    var newFront by remember { mutableStateOf(TireInput(205, 55, 16, 91, TireStandard.STD, 230)) }
    var newRear by remember { mutableStateOf(newFront.copy()) }
    var result by remember { mutableStateOf<PressureResult?>(null) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        AppHeader("タイヤ空気圧計算", onBack)
        AssistCard("指定空気圧から必要負荷能力を推定し、変更後タイヤの参考空気圧を算出します。前後の指定値が違う車両にも対応。")
        Spacer(Modifier.height(12.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = sameSizeFrontRear, onCheckedChange = {
                sameSizeFrontRear = it
                if (it) {
                    oldRear = oldRear.copy(width = oldFront.width, aspect = oldFront.aspect, rim = oldFront.rim, loadIndex = oldFront.loadIndex, standard = oldFront.standard)
                    newRear = newRear.copy(width = newFront.width, aspect = newFront.aspect, rim = newFront.rim, loadIndex = newFront.loadIndex, standard = newFront.standard)
                }
            })
            Spacer(Modifier.width(10.dp))
            Column {
                Text("前後タイヤサイズ同一", fontWeight = FontWeight.Bold)
                Text("ONでも指定空気圧は前後別に設定できます", style = MaterialTheme.typography.bodySmall)
            }
        }

        Spacer(Modifier.height(14.dp))
        SectionTitle("純正 / 変更前")
        TireEditor("フロント", oldFront, showPressure = true) {
            oldFront = it
            if (sameSizeFrontRear) oldRear = oldRear.copy(width = it.width, aspect = it.aspect, rim = it.rim, loadIndex = it.loadIndex, standard = it.standard)
        }
        Spacer(Modifier.height(8.dp))
        if (sameSizeFrontRear) {
            PressureOnlyEditor("リア指定空気圧", oldRear.pressureKpa) { oldRear = oldRear.copy(pressureKpa = it) }
        } else {
            TireEditor("リア", oldRear, showPressure = true) { oldRear = it }
        }

        Spacer(Modifier.height(18.dp))
        SectionTitle("変更後")
        TireEditor("フロント", newFront, showPressure = false) {
            newFront = it
            if (sameSizeFrontRear) newRear = newRear.copy(width = it.width, aspect = it.aspect, rim = it.rim, loadIndex = it.loadIndex, standard = it.standard)
        }
        Spacer(Modifier.height(8.dp))
        if (!sameSizeFrontRear) TireEditor("リア", newRear, showPressure = false) { newRear = it }
        else Text("リア：フロントと同じタイヤ仕様", style = MaterialTheme.typography.bodyMedium)

        Spacer(Modifier.height(18.dp))
        Button(
            onClick = {
                val effectiveNewRear = if (sameSizeFrontRear) newFront else newRear
                result = calculatePressure(oldFront, oldRear, newFront, effectiveNewRear)
            },
            modifier = Modifier.fillMaxWidth().height(54.dp)
        ) { Text("推奨空気圧を計算", fontWeight = FontWeight.Bold) }

        result?.let { r ->
            Spacer(Modifier.height(14.dp))
            ResultCard("計算結果") {
                BigResultRow("フロント", "${r.frontKpa} kPa", r.frontStatus)
                HorizontalDivider(Modifier.padding(vertical = 10.dp))
                BigResultRow("リア", "${r.rearKpa} kPa", r.rearStatus)
                Spacer(Modifier.height(10.dp))
                Text("推定必要負荷能力：前 ${r.frontLoadKg.roundToInt()} kg / 後 ${r.rearLoadKg.roundToInt()} kg（タイヤ1本あたり）", style = MaterialTheme.typography.bodySmall)
            }
        }

        Spacer(Modifier.height(14.dp))
        WarningCard("重要：このVer.1の空気圧はLI・規格・基準圧から算出する参考値です。最終決定は車両指定値、タイヤメーカーの負荷能力表、実際の最大空気圧表示を優先してください。LT化では特にメーカー表確認を推奨します。")
        Spacer(Modifier.height(30.dp))
    }
}

@Composable
private fun TireEditor(label: String, tire: TireInput, showPressure: Boolean, onChange: (TireInput) -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text(label, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ChoiceField("幅", tire.width.toString(), widths, Modifier.weight(1f)) { onChange(tire.copy(width = it.toInt())) }
                ChoiceField("扁平", tire.aspect.toString(), aspects, Modifier.weight(1f)) { onChange(tire.copy(aspect = it.toInt())) }
                ChoiceField("R", tire.rim.toString(), rims, Modifier.weight(1f)) { onChange(tire.copy(rim = it.toInt())) }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ChoiceField("LI", tire.loadIndex.toString(), loadIndexes, Modifier.weight(1f)) { onChange(tire.copy(loadIndex = it.toInt())) }
                ChoiceField("規格", tire.standard.label, TireStandard.entries.map { it.label }, Modifier.weight(2f)) { picked ->
                    onChange(tire.copy(standard = TireStandard.entries.first { it.label == picked }))
                }
            }
            Text("${tire.width}/${tire.aspect}R${tire.rim} ${tire.loadIndex}  •  ${tire.standard.label}", style = MaterialTheme.typography.bodySmall)
            if (showPressure) {
                ChoiceField("メーカー指定空気圧", "${tire.pressureKpa} kPa", pressureValues.map { "$it kPa" }, Modifier.fillMaxWidth()) {
                    onChange(tire.copy(pressureKpa = it.substringBefore(" ").toInt()))
                }
            }
        }
    }
}

@Composable
private fun PressureOnlyEditor(label: String, pressure: Int, onChange: (Int) -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(14.dp)) {
            ChoiceField(label, "$pressure kPa", pressureValues.map { "$it kPa" }, Modifier.fillMaxWidth()) {
                onChange(it.substringBefore(" ").toInt())
            }
        }
    }
}

@Composable
private fun TireDiameterScreen(onBack: () -> Unit) {
    var oldTire by remember { mutableStateOf(TireInput(195, 65, 15)) }
    var newTire by remember { mutableStateOf(TireInput(205, 55, 16)) }
    var calculated by remember { mutableStateOf(false) }

    val oldD = tireDiameterMm(oldTire)
    val newD = tireDiameterMm(newTire)
    val diff = newD - oldD
    val diffPct = diff / oldD * 100.0
    val speed40 = 40.0 * newD / oldD
    val speed100 = 100.0 * newD / oldD

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        AppHeader("タイヤ外径計算", onBack)
        AssistCard("純正と変更後を選ぶだけで外径差、車高変化、速度計の参考誤差を計算します。")
        Spacer(Modifier.height(14.dp))
        SectionTitle("純正サイズ")
        DiameterEditor(oldTire) { oldTire = it; calculated = false }
        Spacer(Modifier.height(14.dp))
        SectionTitle("変更後サイズ")
        DiameterEditor(newTire) { newTire = it; calculated = false }
        Spacer(Modifier.height(18.dp))
        Button(onClick = { calculated = true }, modifier = Modifier.fillMaxWidth().height(54.dp)) {
            Text("外径を計算", fontWeight = FontWeight.Bold)
        }
        if (calculated) {
            Spacer(Modifier.height(14.dp))
            ResultCard("計算結果") {
                DataLine("純正外径", "%.1f mm".format(oldD))
                DataLine("変更後外径", "%.1f mm".format(newD))
                DataLine("外径差", "%+.1f mm  (%+.2f%%)".format(diff, diffPct))
                DataLine("車高変化（理論値）", "%+.1f mm".format(diff / 2.0))
                DataLine("メーター40 km/h時", "実速 約 %.1f km/h".format(speed40))
                DataLine("メーター100 km/h時", "実速 約 %.1f km/h".format(speed100))
                Spacer(Modifier.height(8.dp))
                Text(
                    when {
                        kotlin.math.abs(diffPct) <= 1.0 -> "◎ 外径差は小さめ"
                        kotlin.math.abs(diffPct) <= 3.0 -> "○ 外径差は比較的小さい範囲"
                        else -> "⚠ 外径差が大きめ。干渉・速度計・保安基準等を要確認"
                    }, fontWeight = FontWeight.Bold
                )
            }
        }
        Spacer(Modifier.height(14.dp))
        WarningCard("外径計算はタイヤ呼称サイズからの理論値です。実寸は銘柄・空気圧・荷重・リム幅で変わります。適合可否は実車と各種基準を確認してください。")
        Spacer(Modifier.height(30.dp))
    }
}

@Composable
private fun DiameterEditor(tire: TireInput, onChange: (TireInput) -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ChoiceField("幅", tire.width.toString(), widths, Modifier.weight(1f)) { onChange(tire.copy(width = it.toInt())) }
                ChoiceField("扁平", tire.aspect.toString(), aspects, Modifier.weight(1f)) { onChange(tire.copy(aspect = it.toInt())) }
                ChoiceField("R", tire.rim.toString(), rims, Modifier.weight(1f)) { onChange(tire.copy(rim = it.toInt())) }
            }
            Text("${tire.width}/${tire.aspect}R${tire.rim}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun AcDiagnosticScreen(onBack: () -> Unit) {
    var refrigerant by remember { mutableStateOf("R134a") }
    var ambient by remember { mutableStateOf(30) }
    var idleHigh by remember { mutableStateOf(1.20) }
    var idleLow by remember { mutableStateOf(0.25) }
    var rpmHigh by remember { mutableStateOf(1.45) }
    var rpmLow by remember { mutableStateOf(0.18) }
    var vent by remember { mutableStateOf(10) }
    var result by remember { mutableStateOf<AcResult?>(null) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        AppHeader("エアコンガス点検", onBack)
        AssistCard("A/C MAX・内気循環・風量強め・ドア開放など、同じ条件で測定すると比較しやすくなります。")
        Spacer(Modifier.height(14.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ChoiceField("冷媒", refrigerant, listOf("R134a", "R1234yf"), Modifier.weight(1f)) { refrigerant = it }
            ChoiceField("外気温", "$ambient ℃", (10..45).map { "$it ℃" }, Modifier.weight(1f)) { ambient = it.substringBefore(" ").toInt() }
        }

        Spacer(Modifier.height(14.dp))
        SectionTitle("アイドル時")
        PressurePairEditor(idleHigh, idleLow, onHigh = { idleHigh = it }, onLow = { idleLow = it })

        Spacer(Modifier.height(14.dp))
        SectionTitle("2000 rpm時")
        PressurePairEditor(rpmHigh, rpmLow, onHigh = { rpmHigh = it }, onLow = { rpmLow = it })

        Spacer(Modifier.height(14.dp))
        ChoiceField("吹出口温度", "$vent ℃", (0..30).map { "$it ℃" }, Modifier.fillMaxWidth()) { vent = it.substringBefore(" ").toInt() }

        Spacer(Modifier.height(18.dp))
        Button(
            onClick = { result = diagnoseAc(refrigerant, ambient, idleHigh, idleLow, rpmHigh, rpmLow, vent) },
            modifier = Modifier.fillMaxWidth().height(54.dp)
        ) { Text("診断する", fontWeight = FontWeight.Bold) }

        result?.let { r ->
            Spacer(Modifier.height(14.dp))
            ResultCard("診断結果") {
                Text(r.headline, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(r.detail)
                Spacer(Modifier.height(12.dp))
                Text("可能性が高い順", fontWeight = FontWeight.Bold)
                r.causes.forEachIndexed { i, c -> Text("${i + 1}. $c") }
                Spacer(Modifier.height(12.dp))
                Text("次に確認", fontWeight = FontWeight.Bold)
                r.actions.forEach { Text("• $it") }
                Spacer(Modifier.height(10.dp))
                Text("参考正常域（外気温ベース） 高圧 ${"%.2f".format(r.expectedHighMin)}〜${"%.2f".format(r.expectedHighMax)} MPa / 低圧 ${"%.2f".format(r.expectedLowMin)}〜${"%.2f".format(r.expectedLowMax)} MPa", style = MaterialTheme.typography.bodySmall)
            }
        }

        Spacer(Modifier.height(14.dp))
        WarningCard("圧力だけで故障部位を断定する機能ではありません。外気温・湿度・コンデンサー風量・冷媒量・車種制御で値は大きく変わります。異常値では回収量確認、真空保持、規定量充填、温度差確認など実測を優先してください。")
        Spacer(Modifier.height(30.dp))
    }
}

@Composable
private fun PressurePairEditor(high: Double, low: Double, onHigh: (Double) -> Unit, onLow: (Double) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ChoiceField("高圧", "${"%.2f".format(high)} MPa", highPressureValues, Modifier.weight(1f)) { onHigh(it.substringBefore(" ").toDouble()) }
        ChoiceField("低圧", "${"%.2f".format(low)} MPa", lowPressureValues, Modifier.weight(1f)) { onLow(it.substringBefore(" ").toDouble()) }
    }
}

data class AcResult(
    val headline: String,
    val detail: String,
    val causes: List<String>,
    val actions: List<String>,
    val expectedHighMin: Double,
    val expectedHighMax: Double,
    val expectedLowMin: Double,
    val expectedLowMax: Double
)

private fun diagnoseAc(
    refrigerant: String,
    ambient: Int,
    idleHigh: Double,
    idleLow: Double,
    high: Double,
    low: Double,
    vent: Int
): AcResult {
    val yfAdjust = if (refrigerant == "R1234yf") 0.08 else 0.0
    val expectedHighMin = (0.045 * ambient + 0.05 + yfAdjust).coerceAtLeast(0.70)
    val expectedHighMax = (0.060 * ambient + 0.25 + yfAdjust).coerceAtLeast(1.20)
    val expectedLowMin = 0.10
    val expectedLowMax = 0.30

    val causes = mutableListOf<String>()
    val actions = mutableListOf<String>()
    var headline = "概ね正常域"
    var detail = "圧力バランスは大きく外れていません。吹出口温度と実際の冷えをあわせて判断してください。"

    when {
        low <= 0.02 -> {
            headline = "⚠ 低圧側が極端に低い"
            if (high < expectedHighMin) {
                causes += "冷媒不足（漏れを含む）"
                causes += "低圧側の吸い込み過多／冷媒循環量不足"
                causes += "エキスパンションバルブ・配管の絞り"
            } else {
                causes += "エキスパンションバルブ／オリフィスの詰まり・絞り過多"
                causes += "レシーバ／ドライヤ・配管の詰まり"
                causes += "エバポレーター凍結・風量不足"
            }
            detail = "2000rpmで低圧が0 MPa付近または負圧側へ向かうパターンです。冷媒量不足か、循環経路の絞りを優先確認します。"
        }
        high < expectedHighMin * 0.85 && low < expectedLowMin + 0.04 -> {
            headline = "⚠ 高圧・低圧とも低め"
            causes += "冷媒不足"
            causes += "コンプレッサー吐出量不足"
            causes += "外気温に対して負荷が低い／測定条件差"
            detail = "両側とも圧力が低めです。まず回収量を確認し、規定量との差を見ます。"
        }
        high < expectedHighMin * 0.85 && low > expectedLowMax -> {
            headline = "⚠ 圧縮差が小さい"
            causes += "コンプレッサー圧縮不良"
            causes += "可変容量コンプレッサー制御不良"
            causes += "クラッチ／駆動・制御の問題"
            detail = "高圧が上がらず低圧が下がらないため、コンプレッサー側の圧縮能力を疑うパターンです。"
        }
        high > expectedHighMax * 1.15 && low > expectedLowMax -> {
            headline = "⚠ 高圧・低圧とも高め"
            causes += "冷媒過充填"
            causes += "コンデンサー冷却不足（電動ファン・汚れ・風量）"
            causes += "エア混入／真空引き不足"
            detail = "両側が高い場合は過充填と放熱不足を優先確認します。"
        }
        high > expectedHighMax * 1.20 && low <= expectedLowMin -> {
            headline = "⚠ 高圧高め・低圧低め"
            causes += "エキスパンションバルブ／オリフィスの詰まり"
            causes += "レシーバ／ドライヤ・高圧配管の詰まり"
            causes += "冷媒循環の局所的な絞り"
            detail = "高低圧差が大きすぎるパターンです。詰まりや絞り過多を疑います。"
        }
        vent >= 16 && high in expectedHighMin..expectedHighMax && low in expectedLowMin..expectedLowMax -> {
            headline = "⚠ 圧力は近いが冷えが弱い"
            causes += "エアミックスドア／ヒーター側の混入"
            causes += "エバポレーター風量不足・フィルター詰まり"
            causes += "温度センサー／制御系"
            causes += "冷媒量の微妙なズレ"
            detail = "圧力だけでは大きな異常が出ていません。冷媒系以外の温調・風量系も確認します。"
        }
        else -> {
            if (vent <= 12) {
                causes += "現状は大きな異常所見なし"
                detail = "吹出口温度も含め、冷房性能は比較的良好な可能性があります。"
            } else {
                causes += "測定条件差または軽度の冷媒量ズレ"
                causes += "コンデンサー／エバポレーターの熱交換不足"
                causes += "温調制御系"
            }
        }
    }

    if (causes.any { it.contains("冷媒不足") }) {
        actions += "冷媒を回収し、回収量と車両規定量を比較"
        actions += "真空引き → 真空保持確認 → 規定量を定量充填"
        actions += "漏れ痕・UV反応・サービスバルブ周辺を確認"
    }
    if (causes.any { it.contains("詰まり") || it.contains("絞り") }) {
        actions += "配管・エキパン前後の温度差／霜付き位置を確認"
        actions += "規定量充填後も低圧が負圧化するか再確認"
    }
    if (causes.any { it.contains("コンデンサー") || it.contains("過充填") }) {
        actions += "電動ファン作動・コンデンサー汚れ・風量を確認"
        actions += "回収量を確認し過充填を除外"
    }
    if (causes.any { it.contains("コンプレッサー") }) actions += "コンプレッサーON/OFF・吐出温度・制御信号を確認"
    if (actions.isEmpty()) {
        actions += "吹出口温度を継続確認"
        actions += "アイドル→2000rpmで圧力変化が自然か確認"
        actions += "必要なら回収量を測定して規定量と比較"
    }

    // idleとの差がほぼ無い場合の補足
    if (kotlin.math.abs(idleHigh - high) < 0.08 && kotlin.math.abs(idleLow - low) < 0.03) {
        causes.add("回転数を上げても圧力変化が小さいため、コンプレッサー制御状態も要確認")
    }

    return AcResult(headline, detail, causes.distinct(), actions.distinct(), expectedHighMin, expectedHighMax, expectedLowMin, expectedLowMax)
}

private fun calculatePressure(oldFront: TireInput, oldRear: TireInput, newFront: TireInput, newRear: TireInput): PressureResult {
    val frontRequired = estimatedLoadAtPressure(oldFront)
    val rearRequired = estimatedLoadAtPressure(oldRear)
    val front = requiredPressureForLoad(frontRequired, newFront)
    val rear = requiredPressureForLoad(rearRequired, newRear)
    return PressureResult(
        front,
        rear,
        frontRequired,
        rearRequired,
        pressureStatus(front, newFront),
        pressureStatus(rear, newRear)
    )
}

private fun pressureStatus(kpa: Int, tire: TireInput): String = when {
    kpa > tire.standard.referenceKpa -> "⚠ 規格基準圧を超える計算。LI/タイヤ仕様を要確認"
    kpa >= tire.standard.referenceKpa - 10 -> "上限付近"
    else -> "参考範囲"
}

private fun estimatedLoadAtPressure(tire: TireInput): Double {
    val maxLoad = loadIndexKg(tire.loadIndex).toDouble()
    val ratio = (tire.pressureKpa.toDouble() / tire.standard.referenceKpa).coerceIn(0.45, 1.0)
    // タイヤ負荷能力表の形状を簡略近似。Ver.1では安全側に丸めて使用。
    return maxLoad * ratio.pow(0.70)
}

private fun requiredPressureForLoad(requiredLoad: Double, tire: TireInput): Int {
    val maxLoad = loadIndexKg(tire.loadIndex).toDouble()
    if (requiredLoad >= maxLoad) return tire.standard.referenceKpa + 10
    val ratio = (requiredLoad / maxLoad).coerceIn(0.35, 1.0)
    val raw = tire.standard.referenceKpa * ratio.pow(1.0 / 0.70)
    return (ceil(raw / 10.0) * 10.0).roundToInt().coerceAtLeast(150)
}

private fun loadIndexKg(li: Int): Int = loadIndexTable[li] ?: 0

private val loadIndexTable = mapOf(
    60 to 250, 61 to 257, 62 to 265, 63 to 272, 64 to 280, 65 to 290, 66 to 300, 67 to 307, 68 to 315, 69 to 325,
    70 to 335, 71 to 345, 72 to 355, 73 to 365, 74 to 375, 75 to 387, 76 to 400, 77 to 412, 78 to 425, 79 to 437,
    80 to 450, 81 to 462, 82 to 475, 83 to 487, 84 to 500, 85 to 515, 86 to 530, 87 to 545, 88 to 560, 89 to 580,
    90 to 600, 91 to 615, 92 to 630, 93 to 650, 94 to 670, 95 to 690, 96 to 710, 97 to 730, 98 to 750, 99 to 775,
    100 to 800, 101 to 825, 102 to 850, 103 to 875, 104 to 900, 105 to 925, 106 to 950, 107 to 975, 108 to 1000, 109 to 1030,
    110 to 1060, 111 to 1090, 112 to 1120, 113 to 1150, 114 to 1180, 115 to 1215, 116 to 1250, 117 to 1285, 118 to 1320, 119 to 1360,
    120 to 1400, 121 to 1450, 122 to 1500, 123 to 1550, 124 to 1600, 125 to 1650, 126 to 1700
)

private fun tireDiameterMm(t: TireInput): Double = t.rim * 25.4 + 2.0 * t.width * (t.aspect / 100.0)

@Composable
private fun ChoiceField(label: String, value: String, options: List<String>, modifier: Modifier = Modifier, onSelect: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    OutlinedCard(modifier = modifier.clickable { open = true }, shape = RoundedCornerShape(12.dp)) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 9.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall)
            Text("$value  ▼", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
        }
    }
    if (open) {
        AlertDialog(
            onDismissRequest = { open = false },
            title = { Text(label) },
            text = {
                LazyColumn(Modifier.heightIn(max = 430.dp)) {
                    items(options) { option ->
                        Text(
                            option,
                            modifier = Modifier.fillMaxWidth().clickable {
                                onSelect(option)
                                open = false
                            }.padding(vertical = 13.dp, horizontal = 4.dp),
                            fontWeight = if (option == value) FontWeight.Bold else FontWeight.Normal
                        )
                        HorizontalDivider()
                    }
                }
            },
            confirmButton = { TextButton(onClick = { open = false }) { Text("閉じる") } }
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 7.dp))
}

@Composable
private fun AssistCard(text: String) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
        Text(text, Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun WarningCard(text: String) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
        Text(text, Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun ResultCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), elevation = CardDefaults.cardElevation(4.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun BigResultRow(label: String, value: String, status: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, fontWeight = FontWeight.Bold)
            Text(status, style = MaterialTheme.typography.bodySmall)
        }
        Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
    }
}

@Composable
private fun DataLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(label, Modifier.weight(1f))
        Text(value, fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
    }
}

private val widths = (125..355 step 5).map { it.toString() }
private val aspects = (25..85 step 5).map { it.toString() }
private val rims = (10..24).map { it.toString() }
private val loadIndexes = (60..126).map { it.toString() }
private val pressureValues = (150..650 step 10).toList()
private val highPressureValues = (20..320 step 5).map { "%.2f MPa".format(it / 100.0) }
private val lowPressureValues = (-5..60).map { "%.2f MPa".format(it / 100.0) }
